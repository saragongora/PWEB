function validarForm() {
    var form = document.getElementById("mainForm");
    var nome = form.elements["nome"].value;
    var email = form.elements["email"].value;
    var comentario = form.elements["comentario"].value;
    var pesquisa = form.elements["pesquisa"].value;

    if (nome.length < 10) {
        alert("O nome deve ter pelo menos 10 caracteres.");
        return false;
    }

    if (!email.includes("@") || !email.includes(".")) {
        alert("O email deve ser válido.");
        return false;
    }

    if (comentario.length < 20) {
        alert("O comentário deve ter pelo menos 20 caracteres.");
        return false;
    }

    if (pesquisa === "sim") {
        alert("Volte sempre a esta página!");
    } else {
        alert("Que bom que você voltou a visitar esta página!");
    }

    return true;
}

function limparForm() {
    document.getElementById("mainForm").reset();
}
