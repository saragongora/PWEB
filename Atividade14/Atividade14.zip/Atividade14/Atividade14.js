document.addEventListener('DOMContentLoaded', function () {
    const textoInput = document.getElementById('textoInput');
    const maiúsculasCheckbox = document.getElementById('maiúsculasCheckbox');
    const minúsculasCheckbox = document.getElementById('minúsculasCheckbox');

    maiúsculasCheckbox.addEventListener('change', function () {
        if (maiúsculasCheckbox.checked) {
            minúsculasCheckbox.checked = false; // Desmarca o checkbox de minúsculas
            textoInput.value = textoInput.value.toUpperCase();
        } else {
            textoInput.value = textoInput.value.toLowerCase();
        }
    });

    minúsculasCheckbox.addEventListener('change', function () {
        if (minúsculasCheckbox.checked) {
            maiúsculasCheckbox.checked = false; // Desmarca o checkbox de maiúsculas
            textoInput.value = textoInput.value.toLowerCase();
        } else {
            textoInput.value = textoInput.value.toUpperCase();
        }
    });
});
