function abre(imagem) {
    imagem.src = "imagem/img2.png"
    texto = document.getElementById("estado-janela");
    texto.innerHTML = "Janela Aberta";
}

function fecha(imagem) {
    imagem.src = "imagem/img1.png";
    texto = document.getElementById("estado-janela");
    texto.innerHTML = "Janela Fechada";
}

function quebra(imagem) {
    imagem.src = "imagem/img3.png";
    texto = document.getElementById("estado-janela");
    texto.innerHTML = "Janela Quebrada";
}
